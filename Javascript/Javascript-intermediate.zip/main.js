function drawStars(arr) {
  var string="";
  for (let i=0; i<arr.length;i++){
    if(typeof arr[i] === 'number'){
      for (var k=1;k<=arr[i]; k++){
        string = string + "*";
      }
    } else {
      for (var j=1;j<=arr[i].length; j++){
          string += arr[i][0].toLowerCase();
      }
    } 
    
  }
  return string;
  
}

let arr = [4, "Tom", 1, "Michael", 5, 7, "Jimmy Smith"];
drawStars(arr);