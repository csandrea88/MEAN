function random_choice(arr) {
  
  return arr[Math.floor(Math.random() * Math.floor(arr.length))];
}

random_choice([3,5,1,0,-1])

// function create_dummy_array(num) {
  
//   let arr = [];
  
//   for (let i=1;i<=num;i++) {
    
//     arr.push(Math.floor(Math.random() * (9 - 0) + 1));

//   }
  
//   return arr;
  
// }

// create_dummy_array(5);


// function is_even(num) {
  
//   let iseven = false;
  
//   if (num % 2 == 0) {
//     iseven = true;
//   }
//   return iseven;
  
// }
// is_even(6);

// function how_many_even(arr) {
  
//   let isiteven;
//   let cntr = 0;
  
//   for(let i=0; i<arr.length; i++) {
//     isiteven = is_even(arr[i]); 
//     if (isiteven) {
//       cntr++;
//     }
//   }
//   console.log(cntr);
// }


//how_many_even([0,-3,5,6,10,50]);

