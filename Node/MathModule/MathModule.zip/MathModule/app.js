var mathlib = require('./mathlib')();
mathlib.add(2,3);
mathlib.multiply(3,5);
mathlib.square(5);
mathlib.random(1,35);
